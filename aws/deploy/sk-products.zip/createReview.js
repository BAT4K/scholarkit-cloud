// ══════════════════════════════════════════════════════════
// ScholarKit — Hugging Face NLP Review Sentiment
// ─────────────────────────────────────────────────────────
// Phase 3: Tri-Cloud Integration (AWS + Hugging Face)
// Replaces the old GCP logic with Hugging Face API
// ══════════════════════════════════════════════════════════

const { SSMClient, GetParameterCommand } = require('@aws-sdk/client-ssm');
const { docClient } = require('./shared/dynamo');
const { requireAuth } = require('./shared/auth');
const { success, error, options } = require('./shared/response');
const { TABLE_NAME, keys, ENTITY_TYPES } = require('./shared/tableConfig');
const { GetCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');

const ssm = new SSMClient({});

async function getHuggingFaceApiKey() {
  const param = await ssm.send(new GetParameterCommand({
    Name: '/scholarkit/huggingface/api_key',
    WithDecryption: true
  }));
  return param.Parameter.Value;
}

// Helper to make POST request to Hugging Face
async function analyzeSentimentHF(text, apiKey) {
  const response = await fetch(
    "https://router.huggingface.co/hf-inference/models/cardiffnlp/twitter-roberta-base-sentiment-latest",
    {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      method: "POST",
      body: JSON.stringify({ inputs: text }),
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Hugging Face API Error: ${response.status} ${errText}`);
  }

  return await response.json();
}

exports.handler = async (event) => {
  const method = event.httpMethod || event.requestContext?.http?.method;
  if (method === 'OPTIONS') return options();

  try {
    const user = requireAuth(event);
    const body = JSON.parse(event.body || '{}');
    
    // Support either path parameters or body
    const pid = event.pathParameters?.id || body.productId || body.product_id;
    const text = body.reviewText || body.review_text;
    const rating = body.rating || null;

    if (!pid || !text) {
      return error('productId and reviewText are required.', 400);
    }

    // Verify product exists
    const product = await docClient.send(new GetCommand({
      TableName: TABLE_NAME,
      Key: { PK: keys.productPK(pid), SK: keys.productSK() },
    }));
    
    if (!product.Item) return error('Product not found.', 404);

    // ── Call Hugging Face API ──
    const apiKey = await getHuggingFaceApiKey();
    let sentimentLabel = 'NEUTRAL';
    let sentimentScoreObj = { positive: 0, negative: 0, neutral: 0, mixed: 0 };
    
    try {
      const hfResult = await analyzeSentimentHF(text, apiKey);

      // hfResult is usually an array of arrays
      if (Array.isArray(hfResult) && Array.isArray(hfResult[0])) {
        const scores = hfResult[0];
        
        // Find highest scoring label
        const topResult = scores.reduce((prev, current) => (prev.score > current.score) ? prev : current);
        
        sentimentLabel = topResult.label.toUpperCase(); // POSITIVE, NEGATIVE, or NEUTRAL
        
        // Map scores
        scores.forEach(s => {
          if (s.label.toUpperCase() === 'POSITIVE') sentimentScoreObj.positive = s.score;
          if (s.label.toUpperCase() === 'NEGATIVE') sentimentScoreObj.negative = s.score;
          if (s.label.toUpperCase() === 'NEUTRAL') sentimentScoreObj.neutral = s.score;
        });

        // Heuristic for MIXED: if it's not predominantly one side, and both pos/neg are significant
        if (sentimentScoreObj.positive > 0.25 && sentimentScoreObj.negative > 0.25 && sentimentScoreObj.neutral < 0.5) {
            sentimentLabel = 'MIXED';
            // We can artificially boost the mixed score for the UI
            sentimentScoreObj.mixed = Math.min(sentimentScoreObj.positive, sentimentScoreObj.negative) * 2;
        }
      }
    } catch (hfErr) {
      console.error("Hugging Face NLP Error:", hfErr);
      console.warn("Hugging Face NLP failed, falling back to neutral:", hfErr.message);
    }

    const createdAt = new Date().toISOString();

    // ── Save to DynamoDB ──
    await docClient.send(new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        PK:         keys.productPK(pid),
        SK:         keys.reviewSK(user.id),
        GSI1PK:     keys.userReviewGSI(user.id),
        GSI1SK:     keys.reviewGSI1SK(pid),
        entityType: ENTITY_TYPES.REVIEW,
        userId:     user.id,
        productId:  Number(pid),
        reviewText: text,
        rating,
        sentiment:  sentimentLabel,
        sentimentScore: sentimentScoreObj,
        sentimentEngine: 'HUGGING_FACE',
        createdAt,
      },
    }));

    return success({
      message: 'Review submitted and analyzed via Hugging Face!',
      product: product.Item.name,
      sentiment: sentimentLabel,
      sentimentScore: sentimentScoreObj,
      engine: 'HUGGING_FACE',
    }, 201);

  } catch (err) {
    console.error('createReview Error:', err);
    if (err.statusCode) return error(err.message, err.statusCode);
    return error(`Internal server error: ${err.message}`, 500);
  }
};
