// ══════════════════════════════════════════════════════════
// ScholarKit — Azure AI Vision Image Moderation
// ─────────────────────────────────────────────────────────
// Phase 3: Tri-Cloud Integration (AWS + Azure)
// Triggered by S3 ObjectCreated event.
// ══════════════════════════════════════════════════════════

const { SSMClient, GetParameterCommand } = require('@aws-sdk/client-ssm');
const { S3Client, GetObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const https = require('https');

const ssm = new SSMClient({});
const s3 = new S3Client({});

async function getAzureConfig() {
  const [endpointParam, keyParam] = await Promise.all([
    ssm.send(new GetParameterCommand({ Name: '/scholarkit/azure/endpoint', WithDecryption: true })),
    ssm.send(new GetParameterCommand({ Name: '/scholarkit/azure/api_key', WithDecryption: true }))
  ]);
  return {
    endpoint: endpointParam.Parameter.Value,
    apiKey: keyParam.Parameter.Value
  };
}

// Helper to analyze image using Azure Vision API
function analyzeImageAzure(imageUrl, endpoint, apiKey) {
  return new Promise((resolve, reject) => {
    // Note: Azure Cognitive Services Vision API v3.2 format
    const data = JSON.stringify({ url: imageUrl });
    
    // endpoint includes https://...
    const url = new URL(`${endpoint}/vision/v3.2/analyze?visualFeatures=Adult,Tags`);
    
    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Ocp-Apim-Subscription-Key': apiKey,
        'Content-Length': data.length
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(JSON.parse(body));
        } else {
          reject(new Error(`Azure API Error: ${res.statusCode} ${body}`));
        }
      });
    });

    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

exports.handler = async (event) => {
  console.log("Received S3 event:", JSON.stringify(event, null, 2));

  try {
    const record = event.Records[0];
    const bucket = record.s3.bucket.name;
    const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));

    console.log(`Processing image s3://${bucket}/${key}`);

    // 1. Fetch Azure config from SSM
    const { endpoint, apiKey } = await getAzureConfig();

    // 2. Generate presigned URL for Azure to read
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const presignedUrl = await getSignedUrl(s3, command, { expiresIn: 900 });

    // 3. Send to Azure AI Vision
    const analysis = await analyzeImageAzure(presignedUrl, endpoint, apiKey);
    console.log("Azure Analysis Result:", JSON.stringify(analysis, null, 2));

    // 4. Moderation logic
    let shouldDelete = false;
    let reason = '';

    if (analysis.adult) {
      if (analysis.adult.isAdultContent || analysis.adult.isRacyContent || analysis.adult.isGoryContent) {
        shouldDelete = true;
        reason = "Adult/Racy/Gory content detected.";
      }
    }

    // You can also check tags here. e.g. require 'clothing'
    const hasClothing = analysis.tags && analysis.tags.some(t => t.name === 'clothing');
    
    if (shouldDelete) {
      console.warn(`[MODERATION FLAG] Deleting image ${key} due to: ${reason}`);
      await s3.send(new DeleteObjectCommand({ Bucket: bucket, Key: key }));
      console.log(`Deleted ${key} from ${bucket}`);
    } else {
      console.log(`[MODERATION PASSED] Image ${key} is safe.`);
    }

    return { statusCode: 200, body: 'Moderation complete.' };

  } catch (err) {
    console.error('Image Moderation Error:', err);
    throw err; // allow Lambda to retry if needed
  }
};
